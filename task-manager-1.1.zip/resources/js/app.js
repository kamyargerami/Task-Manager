require('./bootstrap');
window.$ = window.jQuery = require('jquery');
require('@popperjs/core');
window.bootstrap = require('bootstrap');
require('./custom')
