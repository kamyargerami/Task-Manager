<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" href="<?php echo e(asset('images/favicon.jpg')); ?>" type="image/jpg">

    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="bg-dark">
<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH /home/kamyar/server/task-manager/resources/views/layout.blade.php ENDPATH**/ ?>